package UserLoginReport;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.*;

//import org.apache.log4j.Logger;



public class LogMapper extends MapReduceBase implements Mapper<LongWritable, Text, Text, IntWritable> {
	private final static IntWritable one = new IntWritable(1);
  
//  private static final Logger logger = Logger.getLogger(LogMapper.class);

	public void map(LongWritable key, Text value, OutputCollector<Text, IntWritable> output, Reporter reporter) throws IOException {

    String valueString = value.toString();
    String[] SingleUserLogData = valueString.split(",");
    //logger.info("Feature Name "+ SingleUserLogData[1].toString());
    //logger.info("Login Id "+ SingleUserLogData[27]);
    String featureName = SingleUserLogData[1].toString().replaceAll("^\"|\"$", "");
    if (featureName.equals("Login") || featureName.equals("\"Login\"")) {
      output.collect(new Text(SingleUserLogData[27]), one);
//      output.collect(new Text(SingleUserLogData[1]), one);
    }
	}
}
